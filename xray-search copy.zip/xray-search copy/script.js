document.addEventListener("DOMContentLoaded", function () {
    // Define the query elements
    const companiesInput = document.getElementById("companies");
    const jobTitleInput = document.getElementById("jobTitle");
    const anyKeywordsInput = document.getElementById("anyKeywords");
    const allKeywordsInput = document.getElementById("allKeywords");
    const searchButton = document.getElementById("searchButton");

    // Listen for the button click
    searchButton.addEventListener("click", function () {
        // Get and format companies
        const companies = companiesInput.value.split(",").map(company => `intitle:"${company.trim()}"`).join(" OR ");
        const jobTitle = jobTitleInput.value.trim();

        // Format "Any Keywords" with OR
        const anyKeywords = anyKeywordsInput.value.split(",").map(keyword => `"${keyword.trim()}"`).join(" OR ");

        // Format "All Keywords" with AND
        const allKeywords = allKeywordsInput.value.split(",").map(keyword => `"${keyword.trim()}"`).join(" AND ");

        // Base query components
        const siteQuery = "site:linkedin.com/in";
        const titleQuery = jobTitle ? `intitle:"${jobTitle}"` : "";
        const companyQuery = companies ? `(${companies})` : "";
        const anyKeywordQuery = anyKeywords ? `(${anyKeywords})` : "";
        const allKeywordQuery = allKeywords ? `(${allKeywords})` : "";

        // Combine query parts
        const finalQuery = `${siteQuery} ${titleQuery} AND ${companyQuery} AND ${anyKeywordQuery} AND ${allKeywordQuery}`;

        // Open Google search with the final query
        const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(finalQuery)}`;
        window.open(searchUrl, "_blank");
    });
});
document.getElementById('searchButton').addEventListener('click', function() {
    const companies = document.getElementById('companies').value.trim();
    const jobTitle = document.getElementById('jobTitle').value.trim();
    const anyKeywords = document.getElementById('anyKeywords').value.trim();
    const allKeywords = document.getElementById('allKeywords').value.trim();

    // Build the search query
    let query = 'site:linkedin.com/in';
    if (jobTitle) query += ` (intitle:${jobTitle.split(',').join(' OR intitle:')})`;
    if (companies) query += ` AND (intitle:${companies.split(',').join(' OR intitle:')})`;
    if (anyKeywords) query += ` AND (${anyKeywords.split(',').join(' OR ')})`;
    if (allKeywords) query += ` AND (${allKeywords.split(',').join(' AND ')})`;

    // Send the event to Google Analytics
    gtag('event', 'search_results_generated', {
        'event_category': 'Search Results',
        'event_label': query,
        'value': 1
    });

    // Open the search in a new tab
    window.open(`https://www.google.com/search?q=${encodeURIComponent(query)}`, '_blank');
});
